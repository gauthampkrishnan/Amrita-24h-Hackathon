

<!-- <ul>
	<li><a href="create.php"><strong>Create</strong></a> - Add A User</li>
	<li><a href="read.php"><strong>Search For the </strong>  Student</a></li>
</ul> -->

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pseudo AUMS Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>
<body>

<div class="jumbotron text-center">
  <h1>PSEUDO AUMS</h1>
  <p>Welcome</p> 
</div>
<!-- <?php include "templates/header.php"; ?> -->
<div class="container">
  <div class="row">
    <div class="col-sm-6">
      <p><a href="create.php" class="btn btn-info btn-block">Create new student record</a></p>
    </div>
    <div class="col-sm-6">
      <p><a href="read.php" class="btn btn-info btn-block" height="100%">Search for student</a></p>
    </div>
    <div class="col-sm-12">
      <p><center><a href="operatorlogin.html" class="btn btn-info btn-block" height="100%">Operator Login</a></center></p>
    </div>
  </div>
</div>
<?php include "templates/footer.php"; ?>

</body>
</html>
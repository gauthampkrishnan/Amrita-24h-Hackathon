<?php



if (isset($_POST['submit'])) {
    try  {
        
        require "../config.php";
        require "../common.php";

        $connection = new PDO($dsn, $username, $password, $options);

        $sql = "SELECT * 
                        FROM users
                        WHERE location = :location";

        $location = $_POST['location'];

        $statement = $connection->prepare($sql);
        $statement->bindParam(':location', $location, PDO::PARAM_STR);
        $statement->execute();

        $result = $statement->fetchAll();
    } catch(PDOException $error) {
        echo $sql . "<br>" . $error->getMessage();
    }
}
?>
<?php require "templates/header.php"; ?>
        
<?php  
if (isset($_POST['submit'])) {
    if ($result && $statement->rowCount() > 0) { ?>
        <h2></h2>
<center>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>First-Name </th>
                    <th>Phone Number</th>
                    <th>Email Address</th>
                    <th>Age</th>
                    <th>Roll No</th>
                    <!--<th>Date</th>-->
                </tr>
            </thead>
            <tbody>
			
        <?php foreach ($result as $row) { ?>
            <tr>
                <td><?php echo escape($row["id"]); ?></td>
                <td><?php echo escape($row["firstname"]); ?></td>
                <td><?php echo escape($row["lastname"]); ?></td>
                <td><?php echo escape($row["email"]); ?></td>
                <td><?php echo escape($row["age"]); ?></td>
                <td><?php echo escape($row["location"]); ?></td>
                <td><?php echo escape($row["date"]); ?> </td>
            </tr>
          
        <?php } ?>
        </tbody>
    </table>
<blockquote>The message has been sent to the phone number</blockquote>
	</center>
   
    <?php    
} else { ?>
        <blockquote>No results found for <?php echo escape($_POST['location']); ?>.</blockquote>
    <?php } 
} ?> 
<html>
<head>
<link rel="stylesheet" href="https://unpkg.com/purecss@1.0.0/build/pure-min.css" integrity="sha384-nn4HPE8lTHyVtfCBi5yW9d20FjT8BJwUXyWZT9InLYax14RDjBj46LmSztkmNP9w" crossorigin="anonymous">
<center>
<h2>Find Students based on Roll no</h2>
<body>

<form class="pure-form pure-form-aligned" method="post">
    <label for="location"></label><input align="center" type="text" id="location" placeholder="Roll No" name="location"onkeyup="manage(this)"/>
    <input  type="submit" id="btSubmit" name="submit" value="View Results" disabled/>
</form>
</center>
</body>
<script>
    function manage(location) {
        var bt = document.getElementById('btSubmit');
        if (location.value != '') {
            bt.disabled = false;
        }
        else {
            bt.disabled = true;
        }
    }    
</script>
<center><a  href="index.php">Back to home</a></center>

<?php require "templates/footer.php"; ?>
</html>
